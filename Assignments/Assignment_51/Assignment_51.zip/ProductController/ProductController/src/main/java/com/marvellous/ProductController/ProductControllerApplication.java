package com.marvellous.ProductController;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductControllerApplication.class, args);
	}

}
