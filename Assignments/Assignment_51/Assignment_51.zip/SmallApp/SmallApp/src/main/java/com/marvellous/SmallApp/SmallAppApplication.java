package com.marvellous.SmallApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmallAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmallAppApplication.class, args);
	}

}
