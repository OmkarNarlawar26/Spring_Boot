package com.marvellous.SmallApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmallAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
